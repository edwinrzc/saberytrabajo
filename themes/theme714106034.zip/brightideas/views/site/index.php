<?php $this->pageTitle = Yii::app()->name; ?>
<!-- demo content for the Artisteer theme -->
<table class="art-article" border="0" cellspacing="0" cellpadding="0" style="margin:0;width:100%;">
    <tbody>
        <tr>
            <td style="width:30%;padding:0 20px;">
                <h1>Updates</h1>
                <h4>04/01/2011</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ac felis tellus. Donec ut hendrerit enim.</p>
                <p><br /></p>
                <hr style="border:none;background-color:#dedede;color:#dedede;height:1px;"></hr>
                <h4>04/01/2011</h4>
                <p>Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh, vitae feugiat sapien ante eget mauris.</p>
                <br />
                <hr style="border:none;background-color:#dedede;color:#dedede;height:1px;"></hr>
                <h4>04/01/2011</h4>
                <p>Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget sapien. Pellentesque ac felis tellus.</p>
                <p><br /></p>
                <hr style="border:none;background-color:#dedede;color:#dedede;height:1px;"></hr>
                <h4>04/01/2011</h4>
                <p>Aenean sollicitudin imperdiet arcu, vitae dignissim est posuere id. Duis placerat justo eu nunc interdum ultrices.</p>
            </td>
            <td style="width:35%;padding:0 20px;">
                <h1>Articles</h1>
                <h4>Why We Are In Business</h4>
                <img width="300" height="200" alt="" src="<?php echo Yii::app()->theme->baseUrl; ?>/css/images/shutterstock_17150008.jpg" />
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh, vitae feugiat sapien ante eget mauris. Cras elit nisl, rhoncus nec iaculis ultricies, feugiat eget sapien. Pellentesque ac felis tellus. Aenean sollicitudin imperdiet arcu, vitae dignissim est posuere id. </p>
                <p>Duis placerat justo eu nunc interdum ultrices.Phasellus elit dolor, porttitor id consectetur sit amet, posuere id magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse pharetra auctor pharetra. Nunc a sollicitudin est. Curabitur ullamcorper gravida felis, sit amet.</p>
                <p><a href="#">Continue...</a></p>
            </td>
            <td style="width:35%;padding:0 20px;">
                <h1>Projects</h1>
                <h4>Optimal Logistics</h4>
                <p><img width="102" height="102" alt="" src="<?php echo Yii::app()->theme->baseUrl; ?>/css/images/Delivery.png" style="float:right;margin:5px;" />Amet, consectetur adipiscing elit. Etiam pharetra, tellus sit amet congue vulputate, nisi erat iaculis nibh. Suspendisse pharetra auctor.  <a href="#">More...</a></p>
                <p><br /></p>
                <h4>Work At Home</h4>
                <p><img width="102" height="102" alt="" src="<?php echo Yii::app()->theme->baseUrl; ?>/css/images/Home.png" style="float:right;margin:5px;" />Rhoncus nec iaculis ultricies, feugiat eget sapien. Pellentesque ac felis tellus aenean sollicitudin pharetra auctor pharetra. <a href="#">More...</a></p>
                <p><br /></p>
                <h4>Smart Financing</h4>
                <p><img width="128" height="128" alt="" src="<?php echo Yii::app()->theme->baseUrl; ?>/css/images/Calculator.png" style="float:right;margin:5px;" />Eu nunc interdum ultrices. Phasellus elit dolor, porttitor id consectetur sit amet, posuere id magna a sollicitudin. <a href="#">More...</a></p>
                <p><br /></p>
                <p><span class="art-button-wrapper"><span class="art-button-l"> </span><span class="art-button-r"> </span><a href="#" class="art-button">All Projects</a></span></p>
            </td>
        </tr>
    </tbody>
</table>
